// const RPC_URL = "https://data-seed-prebsc-2-s1.binance.org:8545";
const RPC_URL =
  "https://testnet.velas.com/rpc/";
export const CHAIN_ID = 111;
export default RPC_URL;