export const STEPS = {
  ASSET_SELECTION: "asset_selection",
  FEES_AND_CONFIRM: "fees_and_confirm",
};
