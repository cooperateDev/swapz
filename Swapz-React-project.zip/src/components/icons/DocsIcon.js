import { DocumentTextIcon } from "@heroicons/react/outline";

export default DocumentTextIcon;
